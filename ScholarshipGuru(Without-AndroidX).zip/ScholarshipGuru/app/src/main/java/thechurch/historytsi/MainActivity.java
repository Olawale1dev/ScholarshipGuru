package thechurch.historytsi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdListener;

//import com.facebook.ads.AdRequest;
import com.facebook.ads.AdView;

public class MainActivity extends AppCompatActivity {

    private AdView adView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        WebView webView = findViewById(R.id.xml_webview);
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("https://scholarshipguru.com.ng");


        adView.setAdListener(new AdListener() {
            @Override
            public void onError(Ad ad, AdError adError) {
                // Handle ad load error
            }

            @Override
            public void onAdLoaded(Ad ad) {
                // Handle ad loaded
            }

            @Override
            public void onAdClicked(Ad ad) {
                // Handle ad clicked
            }

            @Override
            public void onLoggingImpression(Ad ad) {
                // Handle logging impression
            }

            // Other AdListener methods...
        });

        adView.loadAd();
    }


    }




}